import React, { useState, useEffect } from 'react';
import '../assets/css/client/HomePage.css';

const HomePage = ({ onNavigate }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const featuredCategories = [
    { name: 'Tapis Berbères', image: 'https://images.unsplash.com/photo-1600164318544-79e50b5b488c?w=400', count: '124 enchères' },
    { name: 'Poteries & Céramiques', image: 'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?w=400', count: '89 enchères' },
    { name: 'Bijoux Traditionnels', image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400', count: '156 enchères' },
    { name: 'Cuirs & Maroquinerie', image: 'https://images.unsplash.com/photo-1547949003-9792a18a2601?w=400', count: '67 enchères' },
  ];

  const featuredAuctions = [
    { id: 1, title: 'Tapis Azilal Vintage 1980', price: '2,500 MAD', timeLeft: '2j 14h', image: 'https://images.unsplash.com/photo-1600164318544-79e50b5b488c?w=400', bids: 12 },
    { id: 2, title: 'Vase Fassi Émaillé', price: '850 MAD', timeLeft: '5j 8h', image: 'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?w=400', bids: 8 },
    { id: 3, title: 'Collier Amber Berbère', price: '1,200 MAD', timeLeft: '1j 6h', image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400', bids: 24 },
  ];

  const stats = [
    { number: '15K+', label: 'Membres actifs' },
    { number: '8K+', label: 'Objets vendus' },
    { number: '98%', label: 'Satisfaction client' },
    { number: '24/7', label: 'Support disponible' },
  ];

  return (
    <div className="homepage">
      {/* Header */}
      <header className={`main-header ${isScrolled ? 'scrolled' : ''}`}>
        <div className="header-container">
          <div className="logo" onClick={() => onNavigate?.('home')}>
            <div className="logo-icon">🔨</div>
            <h2>Bazart.</h2>
          </div>

          <nav className={`main-nav ${mobileMenuOpen ? 'open' : ''}`}>
            <a href="#home" onClick={(e) => { e.preventDefault(); }}>Accueil</a>
            <a href="#auctions" onClick={(e) => { e.preventDefault(); }}>Enchères</a>
            <a href="#categories" onClick={(e) => { e.preventDefault(); }}>Catégories</a>
            <a href="#sell" onClick={(e) => { e.preventDefault(); }}>Vendre</a>
            <a href="#wallet" onClick={(e) => { e.preventDefault(); }}>My Wallet</a>
          </nav>

          <div className="header-actions">
            <button className="btn-outline" onClick={() => onNavigate?.('admin')}>
              Administration
            </button>
            <button className="btn-primary-header" onClick={() => onNavigate?.('auth')}>
              <span>👤</span>
              <span>Connexion</span>
            </button>
            <button className="mobile-menu-btn" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? '✕' : '☰'}
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-bg-pattern"></div>
        <div className="hero-content">
          <div className="hero-badge">🏆 Plateforme d'enchères N°1 au Maroc</div>
          <h1 className="hero-title">
            L'artisanat marocain<br />
            <span className="gradient-text">authentique & rare</span>
          </h1>
          <p className="hero-subtitle">
            Découvrez des pièces uniques d'artisanat traditionnel marocain. 
            Tapis berbères, poteries, bijoux et objets d'art aux enchères.
          </p>
          <div className="hero-buttons">
            <button className="btn-hero-primary" onClick={() => onNavigate?.('auth')}>
              Commencer les enchères →
            </button>
            <button className="btn-hero-secondary" onClick={() => document.getElementById('categories')?.scrollIntoView({ behavior: 'smooth' })}>
              Explorer les catégories
            </button>
          </div>
          <div className="hero-trust">
            <div className="trust-avatars">
              <img src="https://i.pravatar.cc/150?img=1" alt="User" />
              <img src="https://i.pravatar.cc/150?img=2" alt="User" />
              <img src="https://i.pravatar.cc/150?img=3" alt="User" />
              <img src="https://i.pravatar.cc/150?img=4" alt="User" />
              <div className="trust-more">+2k</div>
            </div>
            <p>Rejoignez plus de <strong>15,000 collectionneurs</strong></p>
          </div>
        </div>
        <div className="hero-image">
          <div className="hero-image-card">
            <img 
              src="https://images.unsplash.com/photo-1600164318544-79e50b5b488c?w=600" 
              alt="Artisanat marocain"
            />
            <div className="floating-badge badge-live">
              <span className="live-dot"></span>
              Enchères en direct
            </div>
            <div className="floating-badge badge-price">
              <span>🔥</span>
              À partir de 100 MAD
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="stats-section">
        <div className="stats-container">
          {stats.map((stat, index) => (
            <div className="stat-item" key={index}>
              <div className="stat-number">{stat.number}</div>
              <div className="stat-label">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Categories Section */}
      <section className="categories-section" id="categories">
        <div className="section-header">
          <span className="section-tag">Catégories</span>
          <h2>Explorez nos collections</h2>
          <p>Des trésors artisanaux soigneusement sélectionnés pour vous</p>
        </div>
        <div className="categories-grid">
          {featuredCategories.map((cat, index) => (
            <div className="category-card" key={index} onClick={() => onNavigate?.('categories')}>
              <div className="category-image">
                <img src={cat.image} alt={cat.name} />
                <div className="category-overlay"></div>
              </div>
              <div className="category-info">
                <h3>{cat.name}</h3>
                <span className="category-count">{cat.count}</span>
                <button className="btn-explore">Explorer →</button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Auctions */}
      <section className="auctions-section" id="auctions">
        <div className="section-header">
          <span className="section-tag">Enchères en cours</span>
          <h2>Objets à ne pas manquer</h2>
          <p>Les enchères les plus populaires de cette semaine</p>
        </div>
        <div className="auctions-grid">
          {featuredAuctions.map((auction) => (
            <div className="auction-card" key={auction.id}>
              <div className="auction-image">
                <img src={auction.image} alt={auction.title} />
                <div className="auction-timer">⏱ {auction.timeLeft}</div>
                <div className="auction-bids">🔥 {auction.bids} enchères</div>
              </div>
              <div className="auction-info">
                <h3>{auction.title}</h3>
                <div className="auction-price-row">
                  <div className="current-price">
                    <span className="price-label">Prix actuel</span>
                    <span className="price-value">{auction.price}</span>
                  </div>
                  <button className="btn-bid" onClick={() => onNavigate?.('auth')}>
                    Enchérir
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="section-footer">
          <button className="btn-view-all" onClick={() => onNavigate?.('auth')}>
            Voir toutes les enchères →
          </button>
        </div>
      </section>

      {/* How It Works */}
      <section className="how-it-works">
        <div className="section-header light">
          <span className="section-tag">Comment ça marche</span>
          <h2>Enchérissez en 3 étapes</h2>
        </div>
        <div className="steps-container">
          <div className="step-card">
            <div className="step-icon">1️⃣</div>
            <h3>Créez votre compte</h3>
            <p>Inscrivez-vous gratuitement et vérifiez votre email pour commencer.</p>
          </div>
          <div className="step-connector"></div>
          <div className="step-card">
            <div className="step-icon">2️⃣</div>
            <h3>Trouvez votre trésor</h3>
            <p>Parcourez nos catégories et trouvez l'objet qui vous fait rêver.</p>
          </div>
          <div className="step-connector"></div>
          <div className="step-card">
            <div className="step-icon">3️⃣</div>
            <h3>Enchérissez & Gagnez</h3>
            <p>Placez votre enchère et remportez des pièces uniques.</p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="cta-content">
          <h2>Prêt à découvrir l'exceptionnel ?</h2>
          <p>Rejoignez notre communauté de passionnés et accédez aux plus belles pièces d'artisanat marocain.</p>
          <div className="cta-buttons">
            <button className="btn-cta-primary" onClick={() => onNavigate?.('auth')}>
              Créer mon compte gratuitement
            </button>
            <button className="btn-cta-secondary" onClick={() => onNavigate?.('auth')}>
              Se connecter
            </button>
          </div>
        </div>
        <div className="cta-decoration">
          <div className="cta-circle c1"></div>
          <div className="cta-circle c2"></div>
          <div className="cta-circle c3"></div>
        </div>
      </section>

      {/* Footer */}
      <footer className="main-footer">
        <div className="footer-grid">
          <div className="footer-brand">
            <div className="logo">
              <div className="logo-icon">🔨</div>
              <h2>Bazart.</h2>
            </div>
            <p>La première plateforme d'enchères dédiée à l'artisanat marocain authentique.</p>
            <div className="social-links">
              <span>📘</span>
              <span>📸</span>
              <span>🐦</span>
              <span>▶️</span>
            </div>
          </div>
          <div className="footer-links">
            <h4>Navigation</h4>
            <a href="#home">Accueil</a>
            <a href="#auctions">Enchères</a>
            <a href="#categories">Catégories</a>
            <a href="#sell">Vendre</a>
          </div>
          <div className="footer-links">
            <h4>Support</h4>
            <a href="#faq">FAQ</a>
            <a href="#contact">Contact</a>
            <a href="#terms">Conditions d'utilisation</a>
            <a href="#privacy">Politique de confidentialité</a>
          </div>
          <div className="footer-links">
            <h4>Contact</h4>
            <p>📍 Casablanca, Maroc</p>
            <p>📞 +212 5XX-XXXXXX</p>
            <p>✉️ contact@bazart.ma</p>
          </div>
        </div>
        <div className="footer-bottom">
          <p>© 2026 Bazart. Tous droits réservés. | PFE ENSET Mohammedia</p>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;