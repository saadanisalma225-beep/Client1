// App.js
import React, { useState } from 'react';
import Admin from './admin/AdminLogin';
import Dashboard from './admin/Dashboard';
import Register from './admin/Register';
import HomePage from './client/HomePage';
import AuthPage from './client/AuthPage';
import EmailVerification from './client/EmailVerification';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(!!localStorage.getItem('adminToken'));
  const [currentPage, setCurrentPage] = useState('home');

  const handleLogin = () => {
    setIsLoggedIn(true);
    setCurrentPage('dashboard');
  };

  const handleLogout = () => {
    localStorage.removeItem('adminToken');
    setIsLoggedIn(false);
    setCurrentPage('home');
  };

  // Vérifier si l'utilisateur est connecté (client)
  const isClientLoggedIn = !!localStorage.getItem('token');

  // Lien de vérification d'email (ex: /verify-email/abc123token)
  // Cette vérification passe avant tout le reste, peu importe l'état de connexion.
  const verifyMatch = window.location.pathname.match(/^\/verify-email\/(.+)$/);
  if (verifyMatch) {
    const token = decodeURIComponent(verifyMatch[1]);
    return <EmailVerification token={token} onNavigate={setCurrentPage} />;
  }

  if (isLoggedIn) {
    return <Dashboard onLogout={handleLogout} />;
  }

  switch (currentPage) {
    case 'home':
      return <HomePage onNavigate={setCurrentPage} />;
    case 'auth':
      return <AuthPage onNavigate={setCurrentPage} onLogin={handleLogin} />;
    case 'admin':
      return (
        <div>
          <button 
            onClick={() => setCurrentPage('home')}
            style={{
              position: 'fixed',
              top: '20px',
              left: '20px',
              padding: '10px 20px',
              background: 'white',
              border: '1px solid #ddd',
              borderRadius: '8px',
              cursor: 'pointer',
              zIndex: 1000,
              fontSize: '14px',
              boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
            }}
          >
            ← Retour à l'accueil
          </button>
          <Admin onLogin={handleLogin} onRegisterClick={() => setCurrentPage('register')} />
        </div>
      );
    case 'register':
      return (
        <div>
          <button 
            onClick={() => setCurrentPage('home')}
            style={{
              position: 'fixed',
              top: '20px',
              left: '20px',
              padding: '10px 20px',
              background: 'white',
              border: '1px solid #ddd',
              borderRadius: '8px',
              cursor: 'pointer',
              zIndex: 1000,
              fontSize: '14px',
              boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
            }}
          >
            ← Retour à l'accueil
          </button>
          <Register />
        </div>
      );
    default:
      return <HomePage onNavigate={setCurrentPage} />;
  }
}

export default App;